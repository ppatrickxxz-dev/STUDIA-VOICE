# Build status

- Estrutura Android: criada.
- Runtime padrão: deployment de produção do PabloVoice na Vercel.
- Dependência da `main` vazia do GitHub: removida.
- Upload de arquivos: implementado via seletor nativo.
- Microfone: implementado com permissão em runtime e restrição ao host do PabloVoice.
- Downloads HTTPS + `blob:`/`data:`: implementados.
- Pull-to-refresh, histórico e ciclo foreground/background: implementados.
- XML/resources: validados sintaticamente durante a geração.
- Workflow de build: incluído (`.github/workflows/android.yml`) com Gradle 8.9 + Android SDK.
- APK local: não foi compilado neste ambiente porque Android SDK/Build Tools e Gradle não estavam instalados. O pacote não declara um APK inexistente.
