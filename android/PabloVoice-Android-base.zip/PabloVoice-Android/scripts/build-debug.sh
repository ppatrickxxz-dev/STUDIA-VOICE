#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if command -v gradle >/dev/null 2>&1; then
  exec gradle :app:assembleDebug "$@"
fi

if [[ -x ./gradlew ]]; then
  exec ./gradlew :app:assembleDebug "$@"
fi

echo "Gradle não encontrado. Abra o projeto no Android Studio ou instale Gradle 8.9." >&2
exit 2
