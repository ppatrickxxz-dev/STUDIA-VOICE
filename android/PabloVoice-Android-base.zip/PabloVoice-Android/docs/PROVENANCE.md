# Proveniência do runtime

Base escolhida em 2026-08-25 para evitar reconstruir uma interface diferente da versão viva.

- Vercel team: `TIL`
- Project: `pablovoice-unified-mobile-repair-8-1-1-r2`
- Project ID: `prj_tYUBbnllKLgGOeRKWWB0JQGvmzuq`
- Production deployment ID: `dpl_7WL11CFzK7gH484Ww4i4CySXuE2R`
- Production URL: `https://pablovoice-unified-mobile-repair-8-chi.vercel.app/`
- Deployment state observado: `READY`
- Origem observada: Vercel CLI, sem dependência de commit GitHub para esse deployment.

A URL usada pelo app fica em `gradle.properties` (`pabloVoiceUrl`) e também pode ser sobrescrita com `-PpabloVoiceUrl=...` no build.
