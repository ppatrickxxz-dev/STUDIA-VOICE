# Arquitetura

```text
Android Activity
  └─ WebView hardened shell
       ├─ PabloVoice production HTTPS (Vercel)
       ├─ File chooser → Android Documents UI
       ├─ getUserMedia → RECORD_AUDIO runtime permission
       ├─ HTTPS download → DownloadManager
       └─ blob/data download → native bridge → Downloads/PabloVoice
```

## Decisão

A shell não reimplementa a interface. Isso reduz regressões visuais e funcionais: o mesmo runtime web aprovado é a camada de produto, enquanto Android cuida das integrações do dispositivo.

## Próxima evolução possível

Quando os dois arquivos de origem do deployment forem recuperados/materializados, eles podem ser colocados dentro do próprio projeto Android ou em um repositório-fonte novo. Nesse ponto a dependência de hospedagem também pode ser reduzida.
