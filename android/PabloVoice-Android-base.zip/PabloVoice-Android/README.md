# PabloVoice Android

Base Android empacotável que preserva o PabloVoice web atual e não depende do conteúdo da `main` do repositório antigo.

## Fonte de verdade congelada

Endpoint padrão:

`https://pablovoice-unified-mobile-repair-8-chi.vercel.app/`

O endpoint pode ser trocado sem alterar o Java:

```bash
gradle :app:assembleDebug -PpabloVoiceUrl=https://seu-deploy.vercel.app/
```

## O que a camada Android acrescenta

- WebView HTTPS em tela cheia.
- JavaScript, DOM Storage e cookies para compatibilidade com o app web.
- Upload de arquivos via seletor nativo do Android.
- Permissão de microfone limitada ao host configurado do PabloVoice.
- Reprodução de áudio sem exigir gesto adicional do WebView.
- Download HTTPS com cookies/sessão.
- Download de arquivos gerados por `blob:`/`data:` para `Downloads/PabloVoice` no Android 10+.
- Voltar navega no histórico antes de fechar o app.
- Estado do WebView preservado em recriações da Activity.
- Links externos abrem fora do app.
- TLS inválido é bloqueado; HTTP puro é bloqueado.
- Página local de retry em falha de rede.

## Build

Requisitos locais:

- JDK 17 ou 21
- Android SDK Platform 35
- Android Build Tools 35.x
- Gradle 8.9

### Android Studio

Abra esta pasta como projeto Android e execute `app`.

### Linha de comando

```bash
./scripts/build-debug.sh
```

O script usa Gradle instalado no sistema. O workflow de CI abaixo instala Gradle 8.9 automaticamente.

APK:

`app/build/outputs/apk/debug/app-debug.apk`

### CI

Há um workflow pronto em `.github/workflows/android.yml`. Ele não é necessário para o app funcionar; serve apenas como uma opção futura para compilar automaticamente quando o projeto estiver em um repositório com escrita habilitada.

## Release assinado

A configuração de release/keystore foi deixada de fora de propósito para que nenhuma chave privada seja embutida no projeto. Para Play Store ou APK de distribuição, configure assinatura por segredo/keystore fora do código-fonte.

## Limite atual

Esta versão elimina a dependência da `main` vazia do GitHub, mas **a interface/serviços continuam vindo do deploy HTTPS da Vercel**. Uma versão completamente offline só é possível quando o frontend e os serviços usados pelo PabloVoice forem materializados como arquivos/serviços locais próprios.
